import * as React from 'react';
import { Text, View,Image,TextInput,Button,Alert} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Constants from 'expo-constants';

function HomeScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Image 
      style={{
        resizeMode:'contain' ,
         width: 150,
    height: 150,
    
    
        }}
      source={require("./logo (1).png")}/>

      <Text style={{color:"gray",}}>from</Text>

      <Image source={require("./meta.png")}/>
    </View>
  );
}

function SettingsScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Settings!</Text>
    </View>
  );
}
function FotoScreen(){
  return(
     <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>fotos !</Text>
    </View>
  );
}
function LoginScreen(){
  return(
     <View style={{ flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'withe',
    padding: 0, 
    }}>
       <Image  style={{  
  resizeMode: 'contain',
  width: 270,
  height: 270,
  left:10,         
  }}
     
     source={require("./logo.png")}/>
      <TextInput placeholder="phone number,username or email address"   style={{ height: 40, borderColor: '#DEDEDE', borderWidth: 1 }} ></TextInput>
    
     <TextInput placeholder="password"   style={{ height: 40, borderColor: '#DEDEDE', borderWidth: 1, }} ></TextInput>
    
    <Text style={{marginLeft:200,color:"blue",fontSize:14,paddingBottom:30}}>forgotten password?</Text>
    <Button
        title="Log in"
        onPress={() => Alert.alert('log in feito!')}
      />

     
      <Text style={{}}>-----------------------------or----------------------------</Text>
      
      <Text style={{color:"blue",marginLeft:110}}>log in with faceboock</Text>

       <Image style={{  
  resizeMode: 'contain',
  width: 30,
  height: 30,
  marginLeft:75,
  bottom:24.5, }}
     
     source={require("./face.png")}/>

     <Text style={{marginTop:205,marginLeft:100 }}> dont have an account?</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Home" component={HomeScreen} />
       <Tab.Screen name="foto" component={FotoScreen} />
       <Tab.Screen name="Settings" component={SettingsScreen} />
        <Tab.Screen name="login" component={LoginScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyTabs />
    </NavigationContainer>
  );
}

